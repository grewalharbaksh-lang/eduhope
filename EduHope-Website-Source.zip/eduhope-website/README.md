# EduHope — Learn Today, Lead Tomorrow

A responsive NGO-powered student learning platform concept, built with HTML, CSS and vanilla JavaScript.

## Run locally
1. Extract the ZIP.
2. Open `index.html` in a browser. For best results, use VS Code with the Live Server extension.
3. No build tools or package installation are required.

## Features
- Responsive layout with mobile navigation
- Course category filters and live search
- Course detail dialog with lesson outlines
- Save learning paths using `localStorage`
- Volunteer interest form with browser-side validation and local storage
- Animated impact counters
- Accessible labels, focus states, and reduced-motion support

## Important demo notes
- This is a front-end demonstration. The volunteer form does **not** send data to an organization or backend.
- Impact numbers are explicitly illustrative project goals, not verified results.
- The community reflections are illustrative copy, not real testimonials.
- The donation/financial transaction feature is intentionally not included; connect a verified payment provider and organization account before accepting donations.
- Google Fonts are loaded from the internet. The site still works with fallback fonts when offline.

## Inspect demo submissions
Open the browser developer console and run:
```js
eduHopeDemo.getVolunteerInterests()
eduHopeDemo.getSavedCourses()
```
To clear saved demo data:
```js
eduHopeDemo.clearDemoData()
```

## Suggested next steps before submission
1. Replace illustrative impact goals with verified figures or remove them.
2. Add the foundation's approved logo, contact details, privacy notice and real program information if this is being presented as an official project.
3. Connect the volunteer form to a secure backend or form service if real submissions are required.
4. Test at mobile, tablet and desktop widths.
5. Deploy with GitHub Pages, Netlify or Vercel and add the live URL to your submission.
