const $ = (selector, root = document) => root.querySelector(selector);
const $$ = (selector, root = document) => [...root.querySelectorAll(selector)];

const menuToggle = $("#menuToggle");
const navLinks = $("#navLinks");
menuToggle.addEventListener("click", () => {
  const isOpen = navLinks.classList.toggle("open");
  menuToggle.setAttribute("aria-expanded", String(isOpen));
  menuToggle.setAttribute("aria-label", isOpen ? "Close navigation" : "Open navigation");
});
$$(".nav-links a").forEach(link => link.addEventListener("click", () => {
  navLinks.classList.remove("open");
  menuToggle.setAttribute("aria-expanded", "false");
}));

$("#year").textContent = new Date().getFullYear();

let activeFilter = "all";
const searchInput = $("#courseSearch");
function filterCourses() {
  const query = searchInput.value.trim().toLowerCase();
  let visible = 0;
  $$(".course-card").forEach(card => {
    const matchesFilter = activeFilter === "all" || card.dataset.category === activeFilter;
    const matchesSearch = card.dataset.title.includes(query) || card.textContent.toLowerCase().includes(query);
    const show = matchesFilter && matchesSearch;
    card.hidden = !show;
    if (show) visible++;
  });
  $("#noResults").hidden = visible !== 0;
}
$$(".filter-btn").forEach(button => button.addEventListener("click", () => {
  $$(".filter-btn").forEach(btn => btn.classList.remove("active"));
  button.classList.add("active");
  activeFilter = button.dataset.filter;
  filterCourses();
}));
searchInput.addEventListener("input", filterCourses);

const courseDetails = {
  "Coding foundations": {
    description: "A beginner-friendly introduction to how websites work. Learn by making small things and experimenting.",
    lessons: ["How the web works", "Your first HTML page", "Style it with CSS", "Add a little JavaScript"]
  },
  "Design thinking": {
    description: "Practice turning observations into ideas. This path is about curiosity, empathy and testing simple solutions.",
    lessons: ["Notice a problem", "Understand people", "Sketch possible ideas", "Test and improve"]
  },
  "Communication skills": {
    description: "Build confidence in everyday conversations, teamwork and sharing your ideas clearly.",
    lessons: ["Listen with intention", "Organize your thoughts", "Speak with confidence", "Give and receive feedback", "Work as a team"]
  }
};
const dialog = $("#courseDialog");
let selectedCourse = "";
$$(".course-link").forEach(button => button.addEventListener("click", () => {
  selectedCourse = button.dataset.course;
  const course = courseDetails[selectedCourse];
  $("#dialogTitle").textContent = selectedCourse;
  $("#dialogText").textContent = course.description;
  $("#dialogLessons").innerHTML = course.lessons.map(lesson => `<li>${lesson}</li>`).join("");
  $("#dialogFeedback").textContent = "";
  dialog.showModal();
}));
$("#dialogClose").addEventListener("click", () => dialog.close());
dialog.addEventListener("click", event => {
  if (event.target === dialog) dialog.close();
});
$("#saveCourse").addEventListener("click", () => {
  const saved = JSON.parse(localStorage.getItem("eduhopeSavedCourses") || "[]");
  if (!saved.includes(selectedCourse)) saved.push(selectedCourse);
  localStorage.setItem("eduhopeSavedCourses", JSON.stringify(saved));
  $("#dialogFeedback").textContent = "Saved on this device — you can come back to this learning path.";
});

const volunteerForm = $("#volunteerForm");
volunteerForm.addEventListener("submit", event => {
  event.preventDefault();
  if (!volunteerForm.reportValidity()) return;
  const formData = Object.fromEntries(new FormData(volunteerForm).entries());
  const entries = JSON.parse(localStorage.getItem("eduhopeVolunteerInterests") || "[]");
  entries.push({ ...formData, submittedAt: new Date().toISOString() });
  localStorage.setItem("eduhopeVolunteerInterests", JSON.stringify(entries));
  $("#formFeedback").textContent = `Thanks, ${formData.name.split(" ")[0]}! Your interest has been saved in this browser.`;
  volunteerForm.reset();
});

// Subtle count-up when impact figures enter the viewport.
const counters = $$("[data-count]");
const countObserver = new IntersectionObserver(entries => {
  entries.forEach(entry => {
    if (!entry.isIntersecting || entry.target.dataset.done) return;
    const el = entry.target;
    const target = Number(el.dataset.count);
    const start = performance.now();
    const duration = 1000;
    const tick = now => {
      const progress = Math.min((now - start) / duration, 1);
      const value = Math.floor(target * (1 - Math.pow(1 - progress, 3)));
      el.innerHTML = value.toLocaleString() + (target === 1200 || target === 85 ? "<span>+</span>" : "");
      if (progress < 1) requestAnimationFrame(tick);
    };
    el.dataset.done = "true";
    requestAnimationFrame(tick);
  });
}, { threshold: 0.5 });
counters.forEach(counter => countObserver.observe(counter));

// Demo data helper: use the browser console to inspect saved demo submissions.
window.eduHopeDemo = {
  getVolunteerInterests: () => JSON.parse(localStorage.getItem("eduhopeVolunteerInterests") || "[]"),
  getSavedCourses: () => JSON.parse(localStorage.getItem("eduhopeSavedCourses") || "[]"),
  clearDemoData: () => {
    localStorage.removeItem("eduhopeVolunteerInterests");
    localStorage.removeItem("eduhopeSavedCourses");
  }
};
